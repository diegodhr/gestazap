<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> <?php echo e($parametros['titulo']); ?> </title>
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom/basic.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom/dashboard.css')); ?>" rel="stylesheet">
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">    
</head>

<body>
    
    <header>
        <a class="navbar-brand" href="dashboard">Deporzap</a>
        <form class="d-flex justify-content-end" action="/logout" method="POST">
            <?php echo csrf_field(); ?>
            <button class="material-icons btn btn_salir">logout</button>
        </form>
        <?php echo $__env->yieldContent('cabecera'); ?>
    </header>
    <main>
        <?php echo $__env->yieldContent('contenido'); ?>
    </main>
    <footer>
        <?php echo $__env->yieldContent('pie'); ?>
    </footer>
</body>

</html><?php /**PATH C:\proyecto\gestazap\resources\views/Layout/Elements/plantilla_dashboard.blade.php ENDPATH**/ ?>