<?php
    return array(
        'ROL'=>array(
            'ADMINISTRADOR'=>1,
            'EMPLEADO'=>2
        ),
        'RUTAS'=>array(
            'LOGIN'=>'Login',
            'DASHBOARD'=>'DeporZap',
            'EMPLEADOS'=>'Empleados',
            'NUEVOEMPLEADO'=>'Nuevo empleado',
            'PRODUCTOS'=>'Productos',
            'NUEVOPRODUCTO'=>'Nuevo producto',
            'MODIFICAR'=>'Modificar',
            'NUEVAVENTA'=>'Nueva venta',
            'VERCARRITO'=>'Ver carrito',
        ),
        'TIENDA'=>array(
            'SVD'=>'sivasdescalzo',
            'JD'=>'jdsports',
            'FOOT'=>'footlocker',
        ),
    );
    
?>