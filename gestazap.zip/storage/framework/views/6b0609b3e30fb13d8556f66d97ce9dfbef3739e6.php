

<link href="<?php echo e(asset('css/custom/db_listaprod.css')); ?>" rel="stylesheet">

<?php $__env->startSection('contenido'); ?>

<div class="panel">
    <h1 class="panel-title">Almacén de productos</h1>
    <div class="botones">
        <a href="producto/create" class="btn_accion d-flex align-items-center justify-content-center">
            <i class="material-icons">add_circle_outline</i>&nbsp;
            <i>Agregar producto</i>
        </a>
        <a href="../" class="btn_accion d-flex align-items-center justify-content-center">
            <i class="material-icons">arrow_back</i>&nbsp;
            <i>Volver</i>
        </a>
    </div>
</div>

<?php if($parametros['productos']->isNotEmpty()): ?>

<div class="tbl_panel">
    <table class="tbl_stock">
        <thead>
            <tr>
                <th class="sticky" scope="col">Marca</th>
                <th class="sticky" scope="col">Modelo</th>
                <th class="sticky" scope="col">Talla</th>
                <th class="sticky" scope="col">Unidades</th>
                <th class="sticky" scope="col">Precio</th>
                <th class="sticky" scope="col">Imagen</th>
                <th class="sticky" scope="col"></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $pos = "impar"
            ?>
            <?php $__currentLoopData = $parametros['productos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
            $span = count($producto->tallasUnidades);
            $primero = true;
            ?>
            <?php $__currentLoopData = $producto->tallasUnidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <?php if($primero): ?>
                <td class="<?php echo e($pos); ?>" rowspan="<?php echo e($span); ?>"><?php echo e($producto->marca); ?></td>
                <td class="<?php echo e($pos); ?>" rowspan="<?php echo e($span); ?>"><?php echo e($producto->modelo); ?></td>
                <?php endif; ?>

                <td class="<?php echo e($pos); ?>"><?php echo e($detalles->talla); ?></td>
                <td class="<?php echo e($pos); ?>"><?php echo e($detalles->unidades); ?></td>

                <?php if($primero): ?>
                <td class="<?php echo e($pos); ?>" rowspan="<?php echo e($span); ?>"><?php echo e(number_format($producto->precio, 2)." €"); ?></td>
                <td class="<?php echo e($pos); ?> td_imagen" rowspan="<?php echo e($span); ?>"> <img style="height: 4em"
                        src="<?php echo e($producto->foto); ?>" alt=""> </td>
                <td class="<?php echo e($pos); ?>" rowspan="<?php echo e($span); ?>">
                    <a href="<?php echo e(route('producto.show',$producto->id)); ?>"
                        class="btn_accion d-flex align-items-center justify-content-center">
                        <i class="material-icons">edit</i>
                        <i>Editar</i>
                    </a>
                </td>
                <?php
                $primero=false;
                ?>
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php
            $pos = ($pos=="impar")?$pos="par":$pos="impar";
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>
    <?php else: ?>
    <h1>No hay productos</h1>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.Elements.plantilla_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyecto\gestazap\resources\views/Producto/index.blade.php ENDPATH**/ ?>