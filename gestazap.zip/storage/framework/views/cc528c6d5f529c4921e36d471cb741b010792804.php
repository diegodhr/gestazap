
<link href="<?php echo e(asset('css/custom/db_producto.css')); ?>" rel="stylesheet">

<?php $__env->startSection('contenido'); ?>
<div class="panel">
    <?php if(auth()->user()->rol_id == config('constantes.ROL.ADMINISTRADOR')): ?>
    
    <a href="/dashboard/producto" class="btn_accion btn_volver d-flex align-items-center justify-content-center">
        <i class="material-icons">arrow_back</i>&nbsp;
        <i>Volver</i>
    </a>
    <?php else: ?>
    
    <a href="/venta" class="btn_accion btn_volver d-flex align-items-center justify-content-center">
        <i class="material-icons">arrow_back</i>
        <i>Volver</i>&nbsp;
    </a>
    <?php endif; ?>
</div>

<div class="panel">
    <?php
    $producto = $parametros['producto'];
    ?>
    <div class="titulo_img">
        <div>
            <h2 class="panel-title"><?php echo e($producto->marca); ?></h2>
            <h3 class="panel-title"><?php echo e($producto->modelo); ?></h3>
        </div>
        <?php if(Session::has('nuevo_stock')): ?>
        <div class="alert alert-info alert-dismissible" role="alert">
            <span type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                    aria-hidden="true">&times;</span></span>
            <strong><?php echo e(Session::get('nuevo_stock')); ?></strong>
        </div>
        <?php endif; ?>

        <?php if(Session::has('res_talla')): ?>
        <?php if(session('res_talla')==1): ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
            <span type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                    aria-hidden="true">&times;</span></span>
            <strong>Ya existe esa talla</strong>
        </div>
        <?php else: ?>
        <div class="alert alert-info alert-dismissible" role="alert">
            <span type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                    aria-hidden="true">&times;</span></span>
            <strong>Talla añadida correctamente</strong>
        </div>
        <?php endif; ?>
        <?php
        Session::forget('res_talla');
        ?>
        <?php endif; ?>

        <img src="<?php echo e($producto->foto); ?>" alt="<?php echo e($producto->modelo); ?>">
    </div>

    <?php if(auth()->user()->rol_id == config('constantes.ROL.ADMINISTRADOR')): ?>
    <?php echo $__env->make('Producto.Formulario.stock', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
    <?php echo $__env->make('Producto.Formulario.compra', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.Elements.plantilla_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyecto\gestazap\resources\views/Producto/show.blade.php ENDPATH**/ ?>