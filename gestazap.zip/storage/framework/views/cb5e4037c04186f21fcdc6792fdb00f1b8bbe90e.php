
<link href="<?php echo e(asset('css/custom/nv_venta.css')); ?>" rel="stylesheet">

<?php $__env->startSection('contenido'); ?>
<div class="panel">
    <h2 class="panel-title">Nueva venta</h2>
</div>

<div class="panel panel_botones">
    <form action="/venta/cancelar" method="POST">
        <?php echo csrf_field(); ?>
        <button class="btn_general btn_cancelar d-flex align-items-center justify-content-center">
            <i class="material-icons">close</i>&nbsp;
            <i>Cancelar la venta</i>
        </button>
    </form>
    <?php if(!empty($parametros['productos_venta'])): ?>
    <form action="<?php echo e(route('venta.show',session('venta_id'))); ?>">
        <?php echo csrf_field(); ?>
        <button class="btn_general btn_ver d-flex align-items-center justify-content-center">
            <i class="material-icons">visibility</i>
            <i>Ver venta</i>
        </button>
    </form>
    <?php endif; ?>
</div>
<?php if(Session::has('producto_add')): ?>
<div class="alert alert-info alert-dismissible" role="alert">
    <span type="button" class="close" data-dismiss="alert" aria-label="Close"><span
            aria-hidden="true">&times;</span></span>
    <strong><?php echo e(Session::get('producto_add')); ?></strong>
</div>
<?php endif; ?>
<?php if($parametros['productos']): ?>
<div class="tbl_panel">
    <table class="tbl_stock">
        <thead>
            <tr>
                <th class="sticky">Marca</th>
                <th class="sticky">Modelo</th>
                <th class="sticky">Precio</th>
                <th class="sticky">Foto</th>
                <th class="sticky"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $parametros['productos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($producto->marca); ?></td>
                <td><?php echo e($producto->modelo); ?></td>
                <td><?php echo e(number_format($producto->precio, 2)." €"); ?></td>
                <td class="td_imagen"><img style="height: 4em" src="<?php echo e($producto->foto); ?>"
                        alt="<?php echo e($producto->modelo); ?>"> </td>
                <td>
                    <a class="btn_accion btn_seleccion d-flex align-items-center justify-content-center"
                        href="<?php echo e(route('producto.show',$producto->id)); ?>">
                        <i class="material-icons">add_task</i>&nbsp;
                        <i>Seleccionar</i>
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
<?php else: ?>
<div class="panel">
    <h1 class="panel-title">NO Productos</h1>
</div>
<?php endif; ?>
<?php
Session::forget('producto_add');
?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.Elements.plantilla_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyecto\gestazap\resources\views/Venta/index.blade.php ENDPATH**/ ?>