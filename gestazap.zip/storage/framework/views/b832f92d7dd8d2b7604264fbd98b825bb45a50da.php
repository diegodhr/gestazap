
<link href="<?php echo e(asset('css/custom/db_inicio.css')); ?>" rel="stylesheet">

<?php $__env->startSection('cabecera'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container-fluid d-flex align-items-center justify-content-center lienzo">
    <div class="panel">
        <h1 class="panel-title">Bienvenido <?php echo e($parametros['usuario']['name']); ?></h1>
        <a class="btn_gestion btn_accion" href="dashboard/producto">Gestionar el stock</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.Elements.plantilla_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyecto\gestazap\resources\views/Dashboard/admin.blade.php ENDPATH**/ ?>