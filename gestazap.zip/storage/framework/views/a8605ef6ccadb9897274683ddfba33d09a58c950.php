<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">    
    <title> <?php echo e($parametros['titulo']); ?> </title>    
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom/basic.css')); ?>" rel="stylesheet">
    <link rel="icon" href="<?php echo e(asset('images/favicon.ico')); ?>">
</head>

<body>
    <header>
        <?php echo $__env->yieldContent('cabecera'); ?>
    </header>
    <main class="container-fluid">
        <?php echo $__env->yieldContent('contenido'); ?>
    </main>
    <footer>
        <?php echo $__env->yieldContent('pie'); ?>
    </footer>
</body>

</html><?php /**PATH C:\proyecto\gestazap\resources\views/Layout/Elements/plantilla.blade.php ENDPATH**/ ?>