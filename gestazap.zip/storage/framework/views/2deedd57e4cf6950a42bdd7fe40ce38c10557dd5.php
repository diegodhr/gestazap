
<link href="<?php echo e(asset('css/custom/db_inicio.css')); ?>" rel="stylesheet">

<?php $__env->startSection('cabecera'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<?php if(Session::has('venta_cancelada')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <span type="button" class="close" data-dismiss="alert" aria-label="Close"><span
            aria-hidden="true">&times;</span></span>
    <strong><?php echo e(Session::get('venta_cancelada')); ?></strong>
</div>
<?php endif; ?>
<?php if(Session::has('venta_finalizada')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <span type="button" class="close" data-dismiss="alert" aria-label="Close"><span
            aria-hidden="true">&times;</span></span>
    <strong><?php echo e(Session::get('venta_finalizada')); ?></strong>
</div>
<?php endif; ?>
<div class="container-fluid d-flex align-items-center justify-content-center lienzo">
    <div class="panel">
        <h1 class="panel-title">Bienvenido <?php echo e($parametros['usuario']['name']); ?></h1>
        <form class="btn_gestion" action="/venta">
            <?php echo csrf_field(); ?>
            <button class="btn_accion">Nueva venta</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php
Session::forget('venta_cancelada');
Session::forget('venta_finalizada');
?>
<?php echo $__env->make('Layout.Elements.plantilla_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyecto\gestazap\resources\views/Dashboard/empleado.blade.php ENDPATH**/ ?>