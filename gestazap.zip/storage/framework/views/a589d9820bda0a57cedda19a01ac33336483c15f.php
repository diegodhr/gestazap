<div class="cont_stock">
    <table class="tbl_tallas">
        <thead>
            <tr>
                <th class="sticky">Talla</th>
                <th class="sticky">Stock</th>
                <th class="sticky">Unidades a comprar</th>
                <th class="sticky"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $producto->tallasUnidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form action="<?php echo e(route('venta.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="producto" value="<?php echo e(json_encode($producto,TRUE)); ?>">
                <input type="hidden" name="talla" value="<?php echo e($opcion->talla); ?>">
                <tr>
                    <td><?php echo e($opcion->talla); ?></td>
                    <td><?php echo e($opcion->unidades); ?></td>
                    <td> <input class="unidades_compra" type="number" name="cantidad" id="" min="1" max="<?php echo e($opcion->unidades); ?>"> </td>
                    <td>
                        <button class="btn_add_stock btn_accion" type="submit">                            
                            <i class="material-icons">add_circle_outline</i>&nbsp;
                            <i>Agregar a la compra</i>
                        </button>
                    </td>
                </tr>
            </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH C:\proyecto\gestazap\resources\views/Producto/Formulario/compra.blade.php ENDPATH**/ ?>