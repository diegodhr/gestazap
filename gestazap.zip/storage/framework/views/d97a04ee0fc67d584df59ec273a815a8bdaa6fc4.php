
<h1>Index Login</h1>
<?php echo $__env->make('layouts.plantilla_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyecto\gestazap\resources\views/login/index.blade.php ENDPATH**/ ?>