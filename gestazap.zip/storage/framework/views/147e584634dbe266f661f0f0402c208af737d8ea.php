







<?php $__env->startSection('contenido'); ?>
<h1>Empleados</h1>
<?php if($parametros['empleados']->isNotEmpty()): ?>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>num_empleado</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>DNI</th>
                <th>Fecha de nacimiento</th>
                <th>Fecha de contratación</th>
                <th>teléfono</th>
                <th>email</th>
                <th>categoria</th>
                <th>rol</th>
            </tr>
        </thead>
        <tbody>            
            <?php $__currentLoopData = $parametros['empleados']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($empleado->num_empleado); ?></td>
                <td><?php echo e($empleado->nombre); ?></td>
                <td><?php echo e($empleado->apellido); ?></td>
                <td><?php echo e($empleado->dni); ?></td>
                <td><?php echo e($empleado->fecha_nacimiento); ?></td>
                <td><?php echo e($empleado->fecha_inicio); ?></td>
                <td><?php echo e($empleado->telefono); ?></td>
                <td><?php echo e($empleado->email); ?></td>
                <td><?php echo e($empleado->categoria->nombre); ?></td>
                <td><?php echo e($empleado->rol->tipo); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
            
    </table>
<?php else: ?>
    <h1>No hay empleados</h1>
<?php endif; ?>

<a href="empleado/create" class="btn btn-primary">Agregar nuevo empleado</a>
<a href="../" class="btn btn-primary">Volver</a>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.Elements.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyecto\gestazap\resources\views/Empleado/index.blade.php ENDPATH**/ ?>