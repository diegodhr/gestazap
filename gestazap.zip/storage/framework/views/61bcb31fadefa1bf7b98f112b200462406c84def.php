<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php dump($parametros); ?>
    <title><?php echo e(request()->route()->getName()); ?></title>
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <style>
        html,
        body {
            height: 100%;
        }

        main {
            height: 100%;
        }

        .form-login {
            background-color: rgba(194, 219, 247, 0.562);
            border-radius: .5em;
            padding: 1em;
        }
    </style>
</head>

<body>
    <header>
        <?php echo $__env->yieldContent('cabecera'); ?>
    </header>
    <main class="container">
        <?php echo $__env->yieldContent('contenido'); ?>
    </main>
    <footer>
        <?php echo $__env->yieldContent('pie'); ?>
    </footer>
</body>

</html><?php /**PATH C:\proyecto\gestazap\resources\views/Layout/Elements/plantilla_login.blade.php ENDPATH**/ ?>