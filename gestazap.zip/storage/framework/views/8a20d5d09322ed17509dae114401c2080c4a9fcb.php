









<?php $__env->startSection('contenido'); ?>
<div class="row h-100 justify-content-center align-items-center">
    <div class="col-md-8 col-md-offset-8 form-login">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h1 class="panel-title">Nuevo Usuario</h1>
                <br>
            </div>
            <div class="panel-body">
                <form action="/dashboard/empleado " method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input class="form-control" value="<?php echo e(old('nombre')); ?>" type="text" name="nombre"
                            placeholder="Nombre del empleado" id="nombre" autofocus>
                    </div>
                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                    <div class="form-group">
                        <label for="apellido">Apellido</label>
                        <input class="form-control" value="<?php echo e(old('apellido')); ?>" type="text" name="apellido"
                            placeholder="Apellido del empleado" id="apellido">
                    </div>
                    <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                    <div class="form-group">
                        <label for="dni">DNI</label>
                        <input class="form-control" value="<?php echo e(old('dni')); ?>" type="text" name="dni" placeholder="DNI"
                            id="dni">
                    </div>
                    <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                    <div class="form-group">
                        <label for="fnacimiento">Fecha de nacimiento</label>
                        <input class="form-control" value="<?php echo e(old('fnacimiento')); ?>" type="date" name="fnacimiento"
                            placeholder="Fecha de nacimiento del empleado" id="fnacimiento">
                    </div>
                    <?php $__errorArgs = ['fnacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                    <div class="form-group">
                        <label for="finicio">Fecha de contratación</label>
                        <input class="form-control" value="<?php echo e(old('finicio')); ?>" type="date" name="finicio"
                            placeholder="Fecha de contratacion" id="finicio">
                    </div>
                    <?php $__errorArgs = ['finicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                    <div class="form-group">
                        <label for="telefono">Teléfono</label>
                        <input class="form-control" value="<?php echo e(old('telefono')); ?>" type="text" name="telefono"
                            placeholder="Teléfono" id="telefono">
                    </div>
                    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input class="form-control" value="<?php echo e(old('email')); ?>" type="email" name="email"
                            placeholder="Email" id="email">
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                    
                    <div class="form-group">
                        <label for="rol">Rol de usuario</label>
                        <select class="form-select" aria-label="Default select example" id="rol" name="rol">
                            <?php $__currentLoopData = data_get($parametros,'roles'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=<?php echo e($rol['id']); ?> selected> <?php echo e($rol['tipo']); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                    <div class="form-group">
                        <label for="categoria">Categoria</label>
                        <select class="form-select" aria-label="Default select example" id="categoria" name="categoria">
                            <?php $__currentLoopData = data_get($parametros,'categorias'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=<?php echo e($categoria['id']); ?> selected> <?php echo e($categoria['nombre']); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php $__errorArgs = ['categoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>



                    

                    <br><button class="btn btn-primary col-md-12" type="submit">Agregar</button>
                    <?php $__errorArgs = ['acceso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <br><small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.Elements.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyecto\gestazap\resources\views/Empleado/create.blade.php ENDPATH**/ ?>