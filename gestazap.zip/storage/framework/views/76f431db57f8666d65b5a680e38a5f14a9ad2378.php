<h2>VALIDANDO...</h2>

<?php echo e($datos); ?>


<?php /**PATH C:\proyecto\gestazap\resources\views/Login/valida.blade.php ENDPATH**/ ?>