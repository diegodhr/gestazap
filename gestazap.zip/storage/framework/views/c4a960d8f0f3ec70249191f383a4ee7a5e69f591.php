
<link href="<?php echo e(asset('css/custom/buscar.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('js/main.js')); ?>"></script>

<?php $__env->startSection('contenido'); ?>
<div class="panel">
    <h3 class="panel-title">Buscando producto</h3>
</div>

<div class="popup_carga" id="carga">
    <div class="spinner"></div>
</div>
<div class="panel">
    <a href="../producto" class="btn_accion btn_volver d-flex align-items-center justify-content-center">
        <i class="material-icons">arrow_back</i>&nbsp;
        <i>Volver</i>
    </a>
    <form class="form_buscar" action="/dashboard/producto/buscar" method="post">
        <?php echo csrf_field(); ?>
        <input class="txt_busqueda" type="text" name="criterio" id="id_criterio"
            placeholder="marca y modelo de zapatilla">
        <button class="btn_accion d-flex align-items-center justify-content-center" id="ver" type="submit">
            <i class="material-icons">search</i>&nbsp;
            <i>Buscar</i>
        </button>
    </form>
</div>
<?php if($parametros['busqueda'] != null): ?>
<div class="panel panel_res">
    <?php
    $vacio = true;
    ?>
    <?php $__currentLoopData = $parametros['busqueda']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
        <?php if($producto): ?>
            <?php
            $vacio = false;
            ?>            
            <form action="/dashboard/producto/guardar_producto" method="post" class="card" style="width: 18rem;">
                <?php echo csrf_field(); ?>
                <?php
                $producto['tienda'] = $key;
                ?>
                <input type="hidden" name="producto" value="<?php echo e(json_encode($producto,TRUE)); ?>">
                <h5 class="card-title"><?php echo e($key); ?></h5>
                <img src="<?php echo e($producto['imagen']); ?>" class="card-img" alt="<?php echo e($producto['modelo']); ?>">
                <div class="card-body">
                    <h5 class="lbl_marca"><?php echo e($producto['marca']); ?></h5>
                    <p class="card-text"><?php echo e($producto['modelo']); ?></p>
                    <p class="card-text"><?php echo e(number_format($producto['precio'], 2)." €"); ?></p>
                </div>
                <label class="lbl_datos" for="id_unidades">Unidades</label>
                <input class="txt_datos" type="number" name="unidades" id="id_unidades">
                <label class="lbl_datos" for="id_talla">Talla</label>
                <input class="txt_datos" type="number" name="talla" id="id_talla">
                <button class="btn_accion btn_agregar d-flex align-items-center justify-content-center" type="submit">
                    <i class="material-icons">add_circle_outline</i>
                    <i>Agregar</i>
                </button>
            </form>
        <?php endif; ?>        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php if($vacio): ?>
        <h1 class="panel-title">No hay coincidencias</h1>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.Elements.plantilla_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyecto\gestazap\resources\views/Producto/create.blade.php ENDPATH**/ ?>