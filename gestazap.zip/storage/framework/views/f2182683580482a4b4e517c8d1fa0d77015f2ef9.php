
<link rel="stylesheet" href="<?php echo e('css/custom/login.css'); ?>">
<?php $__env->startSection('contenido'); ?>

<div class="row align-items-center justify-content-center h-100">
    <div class="col-sm-10 col-md-8 col-lg-7 col-xl-5 col-xl-3 d-flex align-items-center" style="height: 100%">

        <div class="panel panel-default w-100 caja">
            <div class="panel-heading">
                <h1 class="panel-title">Acceso de usuarios</h1>
                <br>
            </div>
            <div class="panel-body">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="email">Usuario</label>
                        <input class="form-control" value="<?php echo e(old('email')); ?>" type="email" name="email"
                            placeholder="Email o número de empleado" id="email" autofocus>
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input class="form-control" type="password" name="password" placeholder="Contraseña"
                            id="password">
                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small><br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br><button class="btn btn-primary col-md-12 col-sm-12" type="submit">Acceder</button>
                    <?php $__errorArgs = ['acceso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <br><small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </form>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>









    

    
    


    
    


<?php echo $__env->make('Layout.Elements.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyecto\gestazap\resources\views/Login/index.blade.php ENDPATH**/ ?>