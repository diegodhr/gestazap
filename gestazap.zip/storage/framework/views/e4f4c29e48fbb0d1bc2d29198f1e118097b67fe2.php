
<?php $__env->startSection('cabecera'); ?>
    <?php echo e(session('status')); ?>

    <h1>Cabecera DASHBOARD</h1>    
    <form action="/logout" method="POST">
        <?php echo csrf_field(); ?>
        <button class="btn btn-primary">Salir</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.Elements.plantilla_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyecto\gestazap\resources\views/Dashboard/index.blade.php ENDPATH**/ ?>