<div class="cont_talla">
    <form action="<?php echo e(route('producto.talla')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="producto" value="<?php echo e(json_encode($producto,TRUE)); ?>">
        <label class="lbl_talla" for="id_talla">Nueva talla</label>
        <input type="number" name="nueva_talla" id="id_talla">
        <button class="btn_accion d-flex align-items-center justify-content-center" type="submit">
            <i class="material-icons">add_circle_outline</i>&nbsp;
            <i>Agregar</i>
        </button>
    </form>
    <?php $__errorArgs = ['nueva_talla'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    
</div>

<div class="cont_stock">
    <table class="tbl_tallas">
        <thead>
            <tr>
                <th class="sticky">Talla</th>
                <th class="sticky">Stock</th>
                <th class="sticky">Cantidad</th>
                <th class="sticky"></th>
            </tr>
        </thead>
        <tbody>
            <div>
                <?php $__currentLoopData = $producto->tallasUnidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form action="<?php echo e(route('producto.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="producto" value="<?php echo e(json_encode($producto,TRUE)); ?>">
                    <input type="hidden" name="talla_select" value="<?php echo e($opcion->talla); ?>">
                    <tr>
                        <td><?php echo e($opcion->talla); ?></td>
                        <td><?php echo e($opcion->unidades); ?></td>
                        <td><input class="unidades" type="number" name="cantidad" id=""></td>
                        <td>
                            <button class="btn_add_stock btn_accion" type="submit">
                                <i class="material-icons">add_circle_outline</i>&nbsp;
                                <i>Agregar al stock</i>
                            </button> 
                        </td>
                    </tr>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__errorArgs = ['cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



                <?php
                Session::forget('nuevo_stock');
                ?>

            </div>
        </tbody>
    </table>
</div><?php /**PATH C:\proyecto\gestazap\resources\views/Producto/Formulario/stock.blade.php ENDPATH**/ ?>